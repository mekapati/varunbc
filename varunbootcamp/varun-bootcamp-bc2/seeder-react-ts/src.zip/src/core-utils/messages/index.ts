import homeScreenMessages from "./home";

//your in app text messages go here. This file can be later replaced by external source
const messages = {
    ...homeScreenMessages
};

export default messages;