const homeScreenMessages = {

};

export default homeScreenMessages;