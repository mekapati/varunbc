export const labels = {
    availableCredit: 'Available Credit',
    termCap: 'Term Cap',
    maxInterestRate: 'Max interest rate'
};