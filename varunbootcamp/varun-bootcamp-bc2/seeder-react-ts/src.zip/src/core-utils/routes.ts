export const HOME_ROUTE = '/';
export const DASHBOARD = '/dashboard';
export const USER_PAYMENTS = '/';
export const CASH_ACCELERATION = '/cashAcceleration';
export const REVIEW_ROUTE = '/review';
export const NEW_CASH_KICK = '/new-cash-kick';