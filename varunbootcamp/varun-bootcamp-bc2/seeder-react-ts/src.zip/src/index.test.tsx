// eslint-disable-next-line no-unused-vars
import { assert } from 'console';

it('Test setup', () => {
  expect(1).toBe(1);
});
