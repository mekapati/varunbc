export class UserSettings {
  id!: string;
  interesRate: number = 12;
  currency!: string;
  availableCredit: number = 0;
  termCap: number = 12;
}
