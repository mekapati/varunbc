window.URL.createObjectURL = jest.fn().mockReturnValue("");

export {};