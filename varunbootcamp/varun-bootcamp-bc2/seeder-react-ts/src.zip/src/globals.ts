import { enableFetchMocks } from 'jest-fetch-mock';
import '@testing-library/jest-dom';

enableFetchMocks();
